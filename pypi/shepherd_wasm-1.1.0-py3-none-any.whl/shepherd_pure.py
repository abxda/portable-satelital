# Alias de compatibilidad: el módulo canónico ahora es `shepherd_wasm`
# (paquete PyPI: shepherd-wasm). Este shim mantiene funcionando el código
# escrito con `import shepherd_pure`.
from shepherd_wasm import *          # noqa: F401,F403
from shepherd_wasm import (          # noqa: F401
    SegmentationResult, doShepherdSegmentation, fitSpectralClusters,
    applySpectralClusters, autoMaxSpectralDiff, clump, makeSegSize,
    buildSegmentSpectra, relabelSegments, eliminateSinglePixels,
    eliminateSmallSegments, SegIdType, SEGNULLVAL, MINSEGID, MAX_CLUMP_SIZE,
)
